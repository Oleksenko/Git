#!/bin/sh

composer install --no-dev --prefer-dist --optimize-autoloader --no-interaction
