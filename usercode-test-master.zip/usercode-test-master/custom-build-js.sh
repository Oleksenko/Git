#!/bin/sh

npm install --production
